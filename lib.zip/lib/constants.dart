import 'package:flutter/material.dart';

const KPrimaryColor = Color(0xFFFFC61F);
const KsecondColor = Color(0xFFFFC61F);
const KtextColor = Color(0xFFFFC61F);
const KtextlightColor = Color(0xFFFFC61F);
