class Product {
  final String name;
  final double cost;

  Product({required this.name, required this.cost});
}
